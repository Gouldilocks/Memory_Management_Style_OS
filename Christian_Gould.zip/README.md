 # Running the Program
 * I implemented both what the book says, and a simple running test of the implementation. Both work to my knowledge.

 * This is how to run the pre-determined tests:

 ```
 javac Driver.java
 java Driver
 ```

 * If you want to run it the way the book wants to, then run this, substituting arg for the size of the memory you want:

 ```
 javac Allocator.java
 java Allocator <arg>
 ```